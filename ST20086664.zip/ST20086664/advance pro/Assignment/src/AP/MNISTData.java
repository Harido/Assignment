package AP;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MNISTData  {
		// links string variables to the file location of the MNIST Database
		String train_label_filename = ("MNIST/train-labels.idx1-ubyte");
		String train_image_filename = ("MNIST/train-images.idx3-ubyte");
	
		ArrayList<int[]> image_list;
		ArrayList<int[]> Label_list;
		
		List<BufferedImage> image;
		List<String> Label;
		List<MNISTY> img_dist;
		double dist;
		
		public MNISTData(){
			
			image_list = new ArrayList<int[]>();
			Label_list = new ArrayList<int[]>();
			 
			}
		
		// to get image from the array list
		public ArrayList<int[]> getImages() {
			return image_list;
			}
		
		// to get label from the array list
		public ArrayList<int[]> getLabels() {
			return Label_list;
			}
	
		// method for using the file input stream and read the MNIST database file
		public BufferedImage scan() throws IOException {
		
		
		
		FileInputStream in_stream_labels = null;
		FileInputStream in_stream_image = null;
		
		
		try {
			in_stream_labels = new FileInputStream(new File(train_label_filename));
			in_stream_image = new FileInputStream(new File(train_image_filename));
			
			int labels_start_code = (in_stream_labels.read() << 24) |
					(in_stream_labels.read() << 16) |
					(in_stream_labels.read() << 8) |
					(in_stream_labels.read()); 
			System.out.println("label start code: " + labels_start_code);
			
			int image_start_code = (in_stream_image.read() << 24) |
					(in_stream_image.read() << 16) |
					(in_stream_image.read() << 8) |
					(in_stream_image.read()); 
			System.out.println("image start code: " + image_start_code);
			
			int number_of_labels = (in_stream_labels.read() << 24) |			
					(in_stream_labels.read() << 16) |
					(in_stream_labels.read() << 8) |
					(in_stream_labels.read()); 
			
			int number_of_image = (in_stream_image.read() << 24) |
					(in_stream_image.read() << 16) |
					(in_stream_image.read() << 8) |
					(in_stream_image.read()); 
			
			System.out.println("number of labels and image: " + number_of_labels + " and " + number_of_image);
			
			int image_height = (in_stream_image.read() << 24) |
					(in_stream_image.read() << 16) |
					(in_stream_image.read() << 8) |
					(in_stream_image.read()); 
			
			int image_width = (in_stream_image.read() << 24) |
					(in_stream_image.read() << 16) |
					(in_stream_image.read() << 8) |
					(in_stream_image.read()); 
			System.out.println("Image size: " + image_width + " x " + image_height);
			int image_size = image_width + image_height;
			
			int[] LabelList = new int[number_of_labels];
			int[] image_data= new int[image_width * image_height];
			
			
			for(int record = 0; record < number_of_image; record++) {
				BufferedImage currentImg = new BufferedImage(image_width, image_height, BufferedImage.TYPE_INT_ARGB);
				
				int label = in_stream_labels.read();
				LabelList[record] = label;
				System.out.println(label);
				
				for(int pixel = 0; pixel < image_size; pixel++) {
					
					int gray_value = in_stream_image.read();
					int rgb_value = 0xFF000000 | (gray_value << 16) |
							(gray_value << 8) |
							(gray_value);
					
					image_data[pixel] = rgb_value;
				}
				currentImg.setRGB(0, 0, image_width, image_height, image_data,  0, image_width);
			}
			
			// to add the image data and label list to the array list
			image_list.add(image_data);
			Label_list.add(LabelList);

			
		}catch(FileNotFoundException e) {
			System.out.println("Application Cannot find file " + e.toString());
		}
		return null; 
	}

 
 //KNN algorithm with the Euclidean distance over raw pixels
public void KNN() throws IOException {
	
	BufferedImage org_image = null;
	BufferedImage unknown = null;
	
	double sum = 0.0;
	
		for (int row = 0; row < 28; row ++) {
		for(int col = 0; col < 28; col++) {
			int pixel1 = org_image.getRGB(col, row);
		   int pixel2 = unknown.getRGB(col, row);
		   
		   sum += ((pixel1 - pixel2) * (pixel1 - pixel2));
		   
	for(int i = 0; i < image.size(); i++) {
	
		for(int y = 0; y< org_image.getHeight(); y++) {
		
			for(int x = 0; x <org_image.getWidth(); x++) {
				
				int rgbvalue_org = org_image.getRGB(x,y);
				
				int alpha = (rgbvalue_org >> 24) & 0xff;
				int red = (rgbvalue_org >> 16) & 0xff;
				int green = (rgbvalue_org >> 8) & 0xff;
				int blue = (rgbvalue_org) & 0xff;
				
				int grayscale_org = (int) ((0.3 * red) + (0.59 * green) + (0.11 * blue));
				
				
				int rgbvalue_compressed = unknown.getRGB(x,y);
				
				alpha = (rgbvalue_compressed >> 24) & 0xff;
				red = (rgbvalue_compressed >> 16) & 0xff;
				green = (rgbvalue_compressed >> 8) & 0xff;
				blue = (rgbvalue_compressed) & 0xff;
				
				int grayscale_compressed = (int) ((0.3 * red) + (0.59 * green) + (0.11 * blue));
				
				sum += (Math.pow(grayscale_org - grayscale_compressed, 2));				
	}		
   }
	image.add(org_image);
//	Label.add(org_image);	
	
	dist = Math.sqrt(sum);
//img_dist.add(dist, Label[i]);
	}
	//image.sort(image, dist);
  }
}
 return;
	
  }
}
	
