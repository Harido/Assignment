package AP;

import java.util.List;

public class MNISTY {
	double dist;
	String Label;
	List<MNISTY> img_dist;
}
