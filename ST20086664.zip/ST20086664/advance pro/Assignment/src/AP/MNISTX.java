package AP;

import java.awt.image.BufferedImage;

public class MNISTX {
	BufferedImage image;
	String label;
}
