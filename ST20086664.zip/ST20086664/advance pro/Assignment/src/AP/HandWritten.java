package AP;

 import java.awt.Graphics;
    import java.awt.*;
    import java.awt.event.*;
    import javax.swing.*;
    import javax.swing.GroupLayout.Alignment;
    import javax.swing.LayoutStyle.ComponentPlacement;

    // This class allows the user to draw on the canvas and display and output from what drawn.
    public class HandWritten extends JFrame {
    	
    
    public void HandWrittenGUI(){     

    JFrame frame = new JFrame("Just Paint");    
    frame.getContentPane().setForeground(Color.LIGHT_GRAY);
    frame.getContentPane().setBackground(Color.LIGHT_GRAY);

    Container content = frame.getContentPane();
   
    final  DrawArea drawPad = new  DrawArea();
    

    JPanel panel = new JPanel();
    panel.setBackground(Color.LIGHT_GRAY);

    panel.setPreferredSize(new Dimension(100, 68));
    panel.setMinimumSize(new Dimension(100, 68));
    panel.setMaximumSize(new Dimension(100, 68));

    JButton twoX = new JButton ("2");
    twoX.addActionListener(new ActionListener(){

    	// Calls upon the clear function to clear the canvas
    public void actionPerformed(ActionEvent e){
    drawPad.clear();
        }
    });

    JRadioButton rdbtnPx = new JRadioButton("3 px");
    rdbtnPx.setForeground(Color.WHITE);
    rdbtnPx.setBackground(UIManager.getColor("CheckBox.darkShadow"));

    JRadioButton rdbtnPx_1 = new JRadioButton("5 px");
    rdbtnPx_1.setForeground(Color.WHITE);
    rdbtnPx_1.setBackground(UIManager.getColor("CheckBox.darkShadow"));

    JRadioButton rdbtnPx_2 = new JRadioButton("12 px");
    rdbtnPx_2.setForeground(Color.WHITE);
    rdbtnPx_2.setBackground(UIManager.getColor("CheckBox.darkShadow"));


    ButtonGroup bg = new ButtonGroup();
    bg.add(rdbtnPx);
    bg.add(rdbtnPx_1);
    bg.add(rdbtnPx_2);

    //different options for brush size
    rdbtnPx.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.small();
        }
    });
    rdbtnPx_1.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.medium();
        }
    });
    rdbtnPx_2.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.big();
        }
    });

    JButton clearButton = new JButton("Clear");
    clearButton.setBackground(UIManager.getColor("Button.darkShadow"));
    clearButton.setFont(new Font("Tahoma", Font.PLAIN, 13));

    //calls upon the clear function when selecting the clear button.
    clearButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            drawPad.clear();
        }
    });
    GroupLayout gl_panel = new GroupLayout(panel);
    gl_panel.setHorizontalGroup(
    	gl_panel.createParallelGroup(Alignment.TRAILING)
    		.addGroup(gl_panel.createSequentialGroup()
    			.addContainerGap()
    			.addComponent(clearButton, GroupLayout.PREFERRED_SIZE, 143, GroupLayout.PREFERRED_SIZE)
    			.addPreferredGap(ComponentPlacement.RELATED, 194, Short.MAX_VALUE)
    			.addComponent(rdbtnPx)
    			.addPreferredGap(ComponentPlacement.RELATED)
    			.addComponent(rdbtnPx_1)
    			.addPreferredGap(ComponentPlacement.RELATED)
    			.addComponent(rdbtnPx_2)
    			.addGap(43))
    );
    gl_panel.setVerticalGroup(
    	gl_panel.createParallelGroup(Alignment.LEADING)
    		.addGroup(gl_panel.createSequentialGroup()
    			.addGap(35)
    			.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
    				.addComponent(rdbtnPx_1)
    				.addComponent(rdbtnPx_2)
    				.addComponent(rdbtnPx)
    				.addComponent(clearButton, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
    			.addGap(231))
    );
    panel.setLayout(gl_panel);
    
    JButton scanBtn = new JButton("Scan");
    scanBtn.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent s) {
    	
    	}	
    });
    
    
    
    JPanel panel_1 = new JPanel();
    panel_1.setBackground(Color.BLACK);
    
    // to go to the file open page to upload files.
    JButton trainButton = new JButton("Training");
    trainButton.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent arg0) {
    		FileOpen fp = new FileOpen();
    		fp.FileOpenerGui();
    	}
    });
    
    GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
    groupLayout.setHorizontalGroup(
    	groupLayout.createParallelGroup(Alignment.LEADING)
    		.addGroup(groupLayout.createSequentialGroup()
    			.addGap(22)
    			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
    				.addGroup(groupLayout.createSequentialGroup()
    					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 557, GroupLayout.PREFERRED_SIZE)
    					.addContainerGap())
    				.addGroup(groupLayout.createSequentialGroup()
    					.addGap(20)
    					.addComponent(drawPad, GroupLayout.PREFERRED_SIZE, 286, GroupLayout.PREFERRED_SIZE)
    					.addGap(52)
    					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 279, GroupLayout.PREFERRED_SIZE)
    					.addGap(18)
    					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
    						.addComponent(trainButton, GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
    						.addComponent(scanBtn, GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE))
    					.addGap(21))))
    );
    groupLayout.setVerticalGroup(
    	groupLayout.createParallelGroup(Alignment.LEADING)
    		.addGroup(groupLayout.createSequentialGroup()
    			.addGap(106)
    			.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
    				.addComponent(drawPad, GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
    				.addGroup(groupLayout.createSequentialGroup()
    					.addGap(8)
    					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
    						.addComponent(panel_1, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 229, Short.MAX_VALUE)
    						.addGroup(groupLayout.createSequentialGroup()
    							.addComponent(scanBtn, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
    							.addGap(29)
    							.addComponent(trainButton, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)))))
    			.addPreferredGap(ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
    			.addComponent(panel, GroupLayout.PREFERRED_SIZE, 72, GroupLayout.PREFERRED_SIZE)
    			.addGap(24))
    );
    frame.getContentPane().setLayout(groupLayout);

    frame.setSize(912, 537);

    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    frame.setVisible(true);

}
}

// functionality for the drawing on the canvas.
class DrawArea extends JComponent{

//Image used for user to draw
private Image image;  
//used to draw on
private Graphics2D graphics2D;  
//Mouse coordinates
private int currentX , currentY , oldX , oldY ;

public DrawArea(){
    setDoubleBuffered(false);
   
    //when mouse is pressed functions to save coordinates of x and y 
    addMouseListener(new MouseAdapter(){
        public void mousePressed(MouseEvent e){
            oldX = e.getX();
            oldY = e.getY();
        }
    });
    
    //function coordinate when dragging the mouse to draw line on the canvas
    addMouseMotionListener(new MouseMotionAdapter(){
        public void mouseDragged(MouseEvent e){
            currentX = e.getX();
            currentY = e.getY();
            if(graphics2D != null)
            graphics2D.drawLine(oldX, oldY, currentX, currentY);
            repaint();
            oldX = currentX;
            oldY = currentY;
        }

    });

}   

//Function to paint on the canvas.
public void paintComponent(Graphics g){
    if(image == null){
        image = createImage(getSize().width, getSize().height);
        graphics2D = (Graphics2D)image.getGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        clear();

    }
    g.drawImage(image, 5, 5, null);
}

// function to clear the canvas and remove what's drawn.
public void clear(){
    graphics2D.setPaint(Color.black);
    graphics2D.fillRect(0, 0, getSize().width, getSize().height);
    graphics2D.setPaint(Color.white);
    repaint();
}


// function for brush size when drawing on the canvas.
public void small(){
    graphics2D.setStroke(new BasicStroke(1));;
}
public void medium(){
    graphics2D.setStroke(new BasicStroke(5));;
}
public void big(){
    graphics2D.setStroke(new BasicStroke(12));;
}

}